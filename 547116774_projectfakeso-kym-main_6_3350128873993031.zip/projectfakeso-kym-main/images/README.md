Add data model figures in this directory.
