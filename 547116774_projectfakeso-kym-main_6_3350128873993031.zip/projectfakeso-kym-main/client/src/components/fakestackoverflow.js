export default function fakeStackOverflow() {
  return (
    <h1> Replace with relevant content </h1>
  );
}
