export default class Model {
  constructor() {
    this.data = {
      questions: [
                  {
                    qid: 'q1',
                    title: 'Programmatically navigate using React router',
                    text: 'the alert shows the proper index for the li clicked, and when I alert the variable within the last function I\'m calling, moveToNextImage(stepClicked), the same value shows but the animation isn\'t happening. This works many other ways, but I\'m trying to pass the index value of the list item clicked to use for the math to calculate.',
                    tagIds: ['t1', 't2'],
                    askedBy : 'JoJi John',
                    askDate: new Date('December 17, 2020 03:24:00'),
                    ansIds: ['a1', 'a2'],
                    views: 10,
                  },
                  {
                    qid: 'q2',
                    title: 'android studio save string shared preference, start activity and load the saved string',
                    text: 'I am using bottom navigation view but am using custom navigation, so my fragments are not recreated every time i switch to a different view. I just hide/show my fragments depending on the icon selected. The problem i am facing is that whenever a config change happens (dark/light theme), my app crashes. I have 2 fragments in this activity and the below code is what i am using to refrain them from being recreated.',
                    tagIds: ['t3', 't4', 't2'],
                    askedBy : 'saltyPeter',
                    askDate: new Date('January 01, 2022 21:06:12'),
                    ansIds: ['a3', 'a4', 'a5'],
                    views: 121,
                  }
                ],
      tags: [
        {
          tid: 't1',
          name: 'react',
        },
        {
          tid: 't2',
          name: 'javascript',
        },
        {
          tid: 't3',
          name: 'android-studio',
        },
        {
          tid: 't4',
          name: 'shared-preferences',
        }
      ],

      answers: [
        {
          aid: 'a1',
          text: 'React Router is mostly a wrapper around the history library. history handles interaction with the browser\'s window.history for you with its browser and hash histories. It also provides a memory history which is useful for environments that don\'t have a global history. This is particularly useful in mobile app development (react-native) and unit testing with Node.',
          ansBy: 'hamkalo',
          ansDate: new Date('March 02, 2022 15:30:00'),
        },
        {
          aid: 'a2',
          text: 'On my end, I like to have a single history object that I can carry even outside components. I like to have a single history.js file that I import on demand, and just manipulate it. You just have to change BrowserRouter to Router, and specify the history prop. This doesn\'t change anything for you, except that you have your own history object that you can manipulate as you want. You need to install history, the library used by react-router.',
          ansBy: 'azad',
          ansDate: new Date('January 31, 2022 15:30:00'),
        },
        {
          aid: 'a3',
          text: 'Consider using apply() instead; commit writes its data to persistent storage immediately, whereas apply will handle it in the background.',
          ansBy: 'abaya',
          ansDate: new Date('April 21, 2022 15:25:22'),
        },
        {
          aid: 'a4',
          text: 'YourPreference yourPrefrence = YourPreference.getInstance(context); yourPreference.saveData(YOUR_KEY,YOUR_VALUE);',
          ansBy: 'alia',
          ansDate: new Date('December 02, 2022 02:20:59'),
        },
        {
          aid: 'a5',
          text: 'I just found all the above examples just too confusing, so I wrote my own. ',
          ansBy: 'sana',
          ansDate: new Date('December 31, 2022 20:20:59'),
        }
      ]
    };  
  }
  // add methods to query, insert, and update the model here. E.g.,
  // getAllQstns() {
  //   return this.data.questions;
  // }
  newQuestion(title, text, tagId, username) {
    const tagNames = tagId.split(' ');
    const tagIds = [];
    tagNames.forEach(tagName => {
      const existingTag = this.data.tags.find(tag => tag.name === tagName);
      const tagId = existingTag ? existingTag.tid : this.newTag(tagName).tid;
      tagIds.push(tagId);
    });
    const newQuestion = {
      qid: 'q' + (this.data.questions.length + 1),
      title,
      text,
      tagIds,
      askedBy: username,
      askDate: new Date(),
      ansIds: [],
      views: 0,
    };
    this.data.questions.push(newQuestion);
    return newQuestion;
  }
  
  getQuestionById(qid) {
    return this.data.questions.find((question) => question.qid === qid);
  }

  increaseViewCount(questionId) {
    const question = this.data.questions.find((q) => q.qid === questionId);

    if (question) {
      question.views += 1;
    }
  }

  getAnswersForQuestion(qid) {
    const question = this.data.questions.find((question) => question.qid === qid);
    if (question) {
      return this.data.answers.filter((answer) => question.ansIds.includes(answer.aid));
    }
    return [];
  }


  newTag(name) {
    const newTag = {
      tid:'t'+ (this.data.tags.length + 1),
      name,
    }
    this.data.tags[this.data.tags.length] = newTag;
    return newTag;
  }  

  newAnswer(question, text, username) {
    const newAnswer = {
      aid: 'a' + (this.data.answers.length + 1),
      text,
      ansBy: username,
      ansDate: new Date(),
    };
    this.data.answers.push(newAnswer);
    question.ansIds.push(newAnswer.aid);
    return newAnswer;
  }

  getAllQuestions() {
  return this.data.questions;
  }

  getByQid(qid) {
    for (const question of this.data.questions) {
      if (question.qid === qid) {
        return question;
      }
    }
    return null;
  }

  getAnswerList(question) {
    const AnswerList = []; 
    for (let i = 0; i < question.ansIds.length; i++) {
      for (const answer of this.data.answers) {
        if(question.ansIds[i] === answer.aid) {
          AnswerList.push(answer);
          break;
        }
      }
    }
    return AnswerList;
  }

  searchQuestions(searchInput) {
    const normalizedSearchInput = searchInput.toLowerCase().trim();
  
    if (!normalizedSearchInput) {
      return [];
    }
  
    const searchTerms = normalizedSearchInput.split(' ');
  
    const tagRes = [];
    const wordRes = [];
  
    searchTerms.forEach((term) => {
      if (term.startsWith('[') && term.endsWith(']')) {
        tagRes.push(term.substring(1, term.length - 1));
      } else {
        wordRes.push(term);
      }
    });
  
    const searchResults = this.data.questions.filter((question) => {
      const tagSearchResults = tagRes.some((tag) => {
        return question.tagIds.some((tagId) => {
          const tagObj = this.data.tags.find((t) => t.tid === tagId);
          return tagObj && tagObj.name.toLowerCase() === tag; 
        });
      });
  
      
      const wordSearchResults = wordRes.some((word) => {
        const hasMatchingTitle = question.title.toLowerCase().includes(word);
        const hasMatchingText = question.text.toLowerCase().includes(word);
        const hasMatchingTag = question.tagIds.some((tagId) => {
          const tagObj = this.data.tags.find((t) => t.tid === tagId);
          return tagObj && tagObj.name.toLowerCase().includes(word);
        });
  
        return hasMatchingTitle || hasMatchingText || hasMatchingTag;
      });
  
     
      return tagSearchResults || wordSearchResults;
    });
  
    return searchResults;
  }
  
  sortNewest() {
    const sortedList = this.data.questions.slice();
    sortedList.sort((a, b) => b.askDate - a.askDate);
    return sortedList;
  }

  sortActive() {
    const sortedList = this.data.questions.slice();
    sortedList.sort((a, b) => {
      const getAnsDate = (question) => {
        if (question.ansIds.length === 0) {
          return question.askDate;
        }
        const mostRecentAnswer = this.data.answers
          .filter((answer) => question.ansIds.includes(answer.aid))
          .sort((x, y) => y.ansDate - x.ansDate)[0];
        return mostRecentAnswer.ansDate;
      };
      return getAnsDate(a) - getAnsDate(b);
    });
    return sortedList;
  }

  getUnanswered() {
    return this.data.questions.filter((question) => question.ansIds.length === 0);
  }

  getAllTags(question) {
    let allTagNames = [];
    const tagIds = Array.isArray(question.tagIds) ? question.tagIds : [question.tagIds];
    for (const tagId of tagIds) {
      let tagName = null;
      for (const tag of this.data.tags) {
        if (tag.tid === tagId) {
          tagName = tag.name;
          break;
        }
      }
      if (tagName) {
        allTagNames.push(tagName);
      }
    }
    return allTagNames;
  }
  
  getByTag(tag) {
    let qWithTags = [];
    for (const question of this.data.questions) {
      for (const tId of question.tagIds) {
        if (tId === tag) {
          qWithTags.push(question);
        }
      }
    }
    return qWithTags;
  }
}
