// ************** THIS IS YOUR APP'S ENTRY POINT. CHANGE THIS FILE AS NEEDED. **************
// ************** DEFINE YOUR REACT COMPONENTS in ./components directory **************
import React, { useState } from 'react';
import './stylesheets/App.css';
import Banner from './components/banner.js'
import Menu from './components/menu.js'
import Header from './components/header.js'
import Questions from './components/questions.js'
import Model from './models/model.js';
import NewQuestionForm from './components/NewQuestionForm.js'
import TagsPage from './components/tagsPage.js'
import AnswerPage from './components/AnswerPage.js';
import NewAnswer from './components/NewAnswer';


const model = new Model();

function App() {

  
  const [sortingOrder, setSortingOrder] = useState(''); 
  const [searchResults, setSearchResults] = useState(null);
  const [activeView, setActiveView] = useState('questions');
  const [showQuestionForm, setShowQuestionForm] = useState(false);
  const [selectedTag, setSelectedTag] = useState(null);
  const [numOfQuestions, setNumOfQuestions] = useState(model.getAllQuestions().length);
  const [selectedQuestionId, setSelectedQuestionId] = useState(null);
  const [selectedQuestion, setSelectedQuestion] = useState(null);
  const [selectedAnswers, setSelectedAnswers] = useState([]);
  
  const handleQuestionClick = (questionId) => {
    setActiveView('answers');
    setSelectedQuestionId(questionId);
    model.increaseViewCount(questionId);
    const question = model.getQuestionById(questionId);
    const answers = model.getAnswersForQuestion(questionId);
    setSelectedQuestion(question);
    setSelectedAnswers(answers);
  };

  const handleAnswerQuestionClick = () => {
    setActiveView('newAnswer');
  };

  const handleSort = (order) => {
    setSortingOrder(order);
    setSearchResults(null);
    setSelectedTag(null);
    setNumOfQuestions(model.getAllQuestions().length);
  };

  const handleGetUnanswered = () => {
    setSortingOrder('unanswered'); 
    setSearchResults(null);
    setSelectedTag(null);
    const unansweredCount = model.getUnanswered().length;
    setNumOfQuestions(unansweredCount);
  };

  const handleSearch = (searchInput) => {
    setActiveView('questions');
    setSelectedQuestionId(null);
    const results = model.searchQuestions(searchInput);
    setSearchResults(results || []); 
    setSortingOrder('');
    setNumOfQuestions(results.length);
  };

  const handleAskQuestionClick = () => {
    setShowQuestionForm(true);
  };

  const handleMenuClick = (menuType) => {
    setActiveView(menuType);
    setSortingOrder(null);
    setSearchResults(null);
    setShowQuestionForm(false);
    setSelectedTag(null);
    setNumOfQuestions(model.getAllQuestions().length);
    setSelectedQuestionId(null);
  };

  const handlePostQuestion = (title, text, tags, username) => {
    model.newQuestion(title, text, tags, username);
    setSearchResults(model.getAllQuestions());
    setSortingOrder('newest');
    setShowQuestionForm(false);
    setNumOfQuestions(model.getAllQuestions().length);
    setSelectedQuestionId(null);
    setActiveView('questions');
  };

  const handleTagClick = (tagId) => {
    setActiveView('questions');
    setSortingOrder(null);
    setSearchResults(null);
    setShowQuestionForm(false);
    setSelectedTag(tagId);
    setSelectedQuestionId(null);
  };

  const handlePostAnswer = (answerText, username) => {
    setActiveView('answers');
    const question = model.getQuestionById(selectedQuestionId);
    const newAnswer = model.newAnswer(question, answerText, username);
    setSelectedAnswers([...selectedAnswers, newAnswer]);
  };

  const renderHeader = () => {
    if (showQuestionForm || activeView === 'tags' || activeView === 'answers' || activeView === 'newAnswer') {
      return null;
    }
    return (
      <Header
        model={model}
        onSort={handleSort}
        onGetUnanswered={handleGetUnanswered}
        searchResults={searchResults}
        activeView={activeView}
        onAskQuestionClick={handleAskQuestionClick}
        numOfQuestions={numOfQuestions}
      />
    );
  };
  const renderContent = () => {
    if (showQuestionForm) {
      return <NewQuestionForm model={model} onPostQuestion={handlePostQuestion}/>;
    }

    switch (activeView) {
      case 'questions':
        if (selectedQuestionId) {
          return <AnswerPage model={model} 
          selectedQuestion={selectedQuestion} 
          selectedAnswers = {selectedAnswers}
          onAskQuestionClick={handleAskQuestionClick}/>;
        } else {
        return (
          <div className="questions" id="questionList">
            <Questions 
              model={model}
              sortingOrder={sortingOrder} 
              searchResults={searchResults}
              selectedTag={selectedTag}
              onQuestionClick={handleQuestionClick}
               />
          </div>)
        }
      case 'tags':
        return (
          <section className="section5">
            <TagsPage 
              model={model}
              onAskQuestionClick={handleAskQuestionClick}
              onTagSelect={handleTagClick} 
              selectedTag={selectedTag}
              numOfQuestions={numOfQuestions}
              setNumOfQuestions={setNumOfQuestions}/>
          </section>)
      case 'answers': 
        return (
          <div className="questions" id="questionList">
            <AnswerPage model={model} 
            selectedQuestionId={selectedQuestionId} 
            selectedQuestion={selectedQuestion}
            selectedAnswers={selectedAnswers}
            onAnswerQuestionClick={handleAnswerQuestionClick}
            onAskQuestionClick={handleAskQuestionClick}
            />
          </div>
      );
      case 'newAnswer':
        return (
          <NewAnswer onPostAnswer={handlePostAnswer}/>
        )
      default:
        return null;
    }
  };
  return (
    <section className="fakeso body">
      <Banner onSearch={handleSearch} />
      <div className="main">
        <Menu model={model} 
              setActiveView={handleMenuClick} 
              setSortingOrder={setSortingOrder} 
              setSearchResults={setSearchResults}/>
        <section className="section1">
            {renderHeader()}
            {renderContent()}        
        </section>
      </div>
    </section>
  );
}

export default App;
