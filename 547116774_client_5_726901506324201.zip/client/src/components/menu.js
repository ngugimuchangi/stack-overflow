import React, { useState} from 'react';
import '../stylesheets/menuCss.css';

const Menu = ({ setActiveView, setSortingOrder, setSearchResults}) => {
    const [active, setActive] = useState('questions');

    const clickEvent = (element) => {
        setActive(element);
        setActiveView(element);
        setSortingOrder(null);
        setSearchResults(null);
    }

    return(
        <nav>
            <ul>
                <li className={active === 'questions' ? 'active' : '' } onClick={() => clickEvent('questions')}>
                    <a href="#menuQuestion" id="menuQuestion">Questions</a>
                </li>
                <li className={active === 'tags' ? 'active' : '' } onClick={() => clickEvent('tags')}>
                    <a href="#menuTags" id="menuTags">Tags</a>
                </li> 
            </ul>
        </nav>
        
    )
}

export default Menu;