import Model from '../models/model.js';

export default function FakeStackOverflow() {
  return (
    <h1> Replace with relevant content </h1>
  );
}
  