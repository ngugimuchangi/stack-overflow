import React, { useEffect } from 'react';
import '../stylesheets/headerCss.css';

const Header = ({ onSort, onGetUnanswered, searchResults,  onAskQuestionClick, numOfQuestions }) => {

    useEffect(() => {
      }, [numOfQuestions]);

    const handleSort = (order) => {
        if (typeof onSort === 'function') {
          onSort(order);
        }
      };

      const getUnanswered = () => {
        onGetUnanswered();
      };
    

    return (
        <div>
            <div className="header">
                <h2 id="question-header">{(searchResults && searchResults.length === 0) ? 'No Questions Found' : searchResults ? 'Search Results' :  'All Questions'}</h2>
                <button type="button" className="askQuestion" onClick={onAskQuestionClick}>Ask Question</button>
            </div>
            <div className="filters">
                <h3><span id="numOfQuestions">{numOfQuestions} questions</span></h3>
                <div className="rightcontent">
                    <button className="buttons" id="sortNewest" onClick={() => handleSort('newest')}>Newest</button>
                    <button className="buttons" id="sortActive" onClick={() => handleSort('active')}>Active</button>
                    <button className="buttons" id="getUnanswered" onClick={() => getUnanswered() } >Unanswered</button>
                </div>
            </div>  
        </div>
    );
};

export default Header;