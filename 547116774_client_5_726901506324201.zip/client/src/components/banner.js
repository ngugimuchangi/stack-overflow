import React, { useState } from 'react';
import '../stylesheets/bannerCss.css';

const Banner = ({ onSearch}) => {
  const [searchInput, setSearchInput] = useState('');

  const handleSearchInputChange = (event) => {
    setSearchInput(event.target.value);
  };

  const handleKeyPress = (event) => {
    if (event.key === 'Enter' && searchInput !== "") {
      onSearch(searchInput);
    }
  };

  return (
    <div className='bannerBox'>
      <h1>Fake Stack Overflow</h1>
      <div className='search-bar'>
        <input
          type='text'
          placeholder='Search...'
          id='search-bar'
          value={searchInput}
          onChange={handleSearchInputChange}
          onKeyPress={handleKeyPress}
        />
      </div>
    </div>
  );
};

export default Banner;
