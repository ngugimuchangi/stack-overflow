import React, { useState } from 'react';
import '../stylesheets/NewQuestionForm.css';


function NewQuestionForm({ onPostQuestion }) {

  const [questionTitle, setQuestionTitle] = useState('');
  let [questionText, setQuestionText] = useState('');
  const [tags, setTags] = useState('');
  const [username, setUsername] = useState('');
  let linksArray = [];
  let eachLink = [];

  const handlePostQuestion = () => {
    let candidates = "";
    let isInside = false
    for (let char of questionText) {
      if (char === '[') {
        candidates += char
        isInside = true;
      } else if (char === ')') {
        candidates += char + ' ';
        isInside = false;
      } else if(isInside === true) {
        candidates += char;
      }
    }
    const hyperLinkFormat = /\[([^\]]+)\]\(([^)]+)\)/g;
    
    const matches = candidates.match(hyperLinkFormat);
  

    if (matches) {
      for (const match of matches) {
        
        eachLink = match.match(/\[([^\]]+)\]\(([^)]+)\)/).slice(1);
        if (!eachLink[1].startsWith("http://") && !eachLink[1].startsWith("https://")) {
          alert("Wrong hyperlink format");
          return;
        } else {
          linksArray.push(eachLink);
        }
      }
    }

    if (linksArray.length > 0) {
      for (let j = 0; j < linksArray.length; j++) {
        const linkHtml = `<a href="${linksArray[j][1]}" target="_blank">${linksArray[j][0]}</a>`;
        questionText = questionText.replace(new RegExp(`\\[${linksArray[j][0]}\\]\\(${linksArray[j][1]}\\)`, 'g'), linkHtml);
      }
    }

    if (questionTitle.trim() === '' || questionText.trim() === '' || tags.trim() === '' || username.trim() === '') {
      alert('Write down all field.');
      return;
    }

    if (onPostQuestion) {
      onPostQuestion(questionTitle, questionText, tags, username);
    }

    setQuestionTitle('');
    setQuestionText('');
    setTags('');
    setUsername('');
  };

  return (
    <div className = "allNewQuestion">
      <h2>Question Title*</h2>
      <h4>Limit title to 100 characters or less</h4>
      <input
        type="text"
        placeholder="Question Title"
        value={questionTitle}
        onChange={(e) => setQuestionTitle(e.target.value)}
      />
      <h2>Quesion Text*</h2>
      <h4>Add details</h4>
      <textarea
        placeholder="Question Text"
        value={questionText}
        onChange={(e) => setQuestionText(e.target.value)}
      />
      <h2>Tags*</h2>
      <h4>Add keywords separated by whitespace</h4>
      <input
        type="text"
        placeholder="Tags"
        value={tags}
        onChange={(e) => setTags(e.target.value)}
      />
      <h2>Username*</h2>
      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <div className = "setting">
      <button className ="postQ" onClick={handlePostQuestion}>Post Question</button>
      <h4 className = "redfields">*indicates mandatory fields</h4>
      </div>
    </div>
  );
}

export default NewQuestionForm;


