function AnswerPage({selectedQuestion, selectedAnswers, onAnswerQuestionClick, onAskQuestionClick }) {

  const handleAnswerQuestionClick = () => {
    if (onAnswerQuestionClick) {
      onAnswerQuestionClick(); 
    }
  };
  
  function formatAskDate(askDate) {
    const now = new Date();
    const questionDate = new Date(askDate);
    const timeDiff = now - questionDate;

    if (timeDiff < 86400000) {
      const hours = Math.floor(timeDiff / 3600000);
      const minutes = Math.floor((timeDiff % 3600000) / 60000);
      if (hours > 0) {
        return `${hours}hours ago`;
      } else {
        return `${minutes}minutes ago`;
      }
    } else {
      return questionDate.toLocaleString();
    }
  }

  return (
    <div>
      {selectedQuestion ? ( 
        <>
        <div className = "setting2">
          <h4 className = "bold2">{selectedAnswers.length} answers</h4>
          <div>
            <h3>{selectedQuestion.title}</h3>
          </div>
          <button className = "postQ2" onClick={onAskQuestionClick}>Ask Question</button>
          </div>

          <div className = "setting2-1">
          <div className = "bold2">{selectedQuestion.views} views</div>
          <div className = "text2" dangerouslySetInnerHTML={{ __html: selectedQuestion.text }} />
          <div className = "help2">
          <div className = "red2">{`${selectedQuestion.askedBy}`}</div>
          <div>{`asked ${formatAskDate(selectedQuestion.askDate)}`}</div>
          </div>
          <hr />
          </div>


          <div>
            {selectedAnswers.map((answer, index) => (
              <div key={index} className = "answer-container">
                <div className = "answertext" dangerouslySetInnerHTML={{ __html: answer.text }} />
                <div className = "help2">
                <div className = "green">{`${answer.ansBy}`}</div>
                <div>{`answered ${formatAskDate(answer.ansDate)}`}</div>
                </div>
              </div>
            ))}
          </div>
          <button className = "postQ2" onClick={handleAnswerQuestionClick}>Answer Question</button>
        </>
      ) : (
        <p>Select a question to view answers.</p>
      )}
    </div>
  );
}

export default AnswerPage;
