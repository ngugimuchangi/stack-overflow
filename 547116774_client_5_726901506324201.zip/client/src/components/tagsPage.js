import React, { useState, useEffect } from 'react';
import '../stylesheets/tagsPageCss.css';

const TagsPage = ({ model, onAskQuestionClick,  onTagSelect,  setNumOfQuestions  }) => {
    const [tagCount, setTagCount] = useState([]);

  useEffect(() => {
    const count = model.data.tags.map((tag) => {
      const questionsWithTag = model.getByTag(tag.tid);
      return questionsWithTag.length;
    });
    setTagCount(count);
  }, [model]);

  const handleTagClick = (tagId) => {
    onTagSelect(tagId);
    const questionsWithTag = model.getByTag(tagId);
    setNumOfQuestions(questionsWithTag.length);
  };


  const groupedTags = [];
  for (let i = 0; i < model.data.tags.length; i += 3) {
    groupedTags.push(model.data.tags.slice(i, i + 3));
  }

  return (
    <div> 
      <div className="tagsHeader">
        <div><h2><span id="totalTags">{model.data.tags.length}</span> Tags</h2></div>
        <div><h2>All Tags</h2></div>
        <div><button type="button" className="askQuestion" id="tagPageQ" onClick={onAskQuestionClick}>Ask Question</button></div>
      </div>

      {groupedTags.map((group, index) => (
        <div key={index} className="tagRow">
          {group.map((tag, tagIndex) => (
            <div className='tag123' key={tag.tid}>
              <a href="#" className="tagName" onClick={() => handleTagClick(tag.tid)}>{tag.name}</a>
              <div className="tagCount">{tagCount[tagIndex]} questions</div>
            </div>
          ))}
        </div>
      ))}<div className = "b"></div>
    </div>
  );
};

export default TagsPage;
