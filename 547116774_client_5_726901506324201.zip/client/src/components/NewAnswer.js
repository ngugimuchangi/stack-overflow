import React, {useState} from 'react';

function NewAnswer({onPostAnswer}) {

    let [answerText, setAnswerText] = useState('');
    const [username, setUsername] = useState('');
    let linksArray = [];
    let eachLink = [];

    const handlePostAnswer = () => {   

      let candidates = "";
    let isInside = false
    for (let char of answerText) {
      if (char === '[') {
        candidates += char
        isInside = true;
      } else if (char === ')') {
        candidates += char + ' ';
        isInside = false;
      } else if(isInside === true) {
        candidates += char;
      }
    }
    const hyperLinkFormat = /\[([^\]]+)\]\(([^)]+)\)/g;
    
    const matches = candidates.match(hyperLinkFormat);
  

    if (matches) {
      for (const match of matches) {
        
        eachLink = match.match(/\[([^\]]+)\]\(([^)]+)\)/).slice(1);
        if (!eachLink[1].startsWith("http://") && !eachLink[1].startsWith("https://")) {
          alert("Wrong hyperlink format");
          return;
        } else {
          linksArray.push(eachLink);
        }
      }
    }

    if (linksArray.length > 0) {
      for (let j = 0; j < linksArray.length; j++) {
        const linkHtml = `<a href="${linksArray[j][1]}" target="_blank">${linksArray[j][0]}</a>`;
        answerText = answerText.replace(new RegExp(`\\[${linksArray[j][0]}\\]\\(${linksArray[j][1]}\\)`, 'g'), linkHtml);
      }
    }

      if (onPostAnswer) {
        onPostAnswer(answerText, username);
      } 
        setAnswerText('');
        setUsername('');
    };

    return (
        <div>
      <h2>Username*</h2>
      <input
            type="text"
            placeholder="Username*"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
      />
      <h2>Answer Text*</h2>
        <textarea
            placeholder="AnswerText"
            value={answerText}
            onChange={(e) => setAnswerText(e.target.value)}
      />

        <div className = "setting">
        <button className = "postQ" onClick={handlePostAnswer}>Post Answer</button>

        <h4 className = "redfields">* indicates mandatory fields</h4>
        </div>     
          
        </div>
      );


}

export default NewAnswer;