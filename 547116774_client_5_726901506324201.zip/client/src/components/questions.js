import React, { useState, useEffect } from 'react';
import '../stylesheets/questionCss.css';



const questionTime = (question) => {
    let timePassed = Math.floor(((new Date()) - new Date(question.askDate)) / 1000);


    const options = {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
    };

    let timeMetric =
      timePassed === 1
        ? timePassed + ' second ago'
        : timePassed < 60
        ? timePassed + ' seconds ago'
        : timePassed < 120
        ? Math.floor(timePassed / 60) + ' minute ago'
        : timePassed < 3600
        ? Math.floor(timePassed / 60) + ' minutes ago'
        : timePassed < 7200
        ? Math.floor(timePassed / 3600) + ' hour ago'
        : timePassed < 86400
        ? Math.floor(timePassed / 3600) + ' hours ago'
        : new Date(question.askDate).toLocaleDateString(undefined, options);

    return timeMetric;
  };


const Questions = ({ model, sortingOrder, searchResults, selectedTag, onQuestionClick}) => {
    const [sortedQuestions, setSortedQuestions] = useState([]);

    useEffect(() => {
        if (selectedTag) {
          const questionsWithSelectedTag = model.getByTag(selectedTag);
          setSortedQuestions(questionsWithSelectedTag);
        } else if (sortingOrder === 'unanswered') {
          getUnanswered();
        } else if (sortingOrder) {
          sortQuestions(sortingOrder);
        } else {
          setSortedQuestions(model.getAllQuestions());
        }
      }, [sortingOrder, searchResults, selectedTag]);

      const sortQuestions = (order) => {
        let sortedList;
    
        switch (order) {
          case 'newest':
            sortedList = model.sortNewest();
            break;
          case 'active':
            sortedList = model.sortActive();
            break;
          default:
            sortedList = model.getAllQuestions();
        }
        setSortedQuestions(sortedList);
      };

      const getUnanswered = () => {
        const unansweredList = model.getUnanswered();
        setSortedQuestions(unansweredList);
      };
    
      const allQuestions = (searchResults && searchResults.length > 0) ? searchResults : (searchResults && searchResults.length === 0) ? [] :
      selectedTag ? sortedQuestions :  sortingOrder === 'unanswered' ? sortedQuestions : sortingOrder ? sortedQuestions : model.getAllQuestions();
      
    return(
        <div>
            {allQuestions.length > 0 ? allQuestions.map((question) => (
                <div className="question" id="eachQuestion" key={question.qid}>
                    <div className='rowElements'>
                        <div className="stats">
                            <span id="numOfAns">{question.ansIds.length} answers</span>
                            <span id="numOfViews">{question.views} views</span>
                        </div>
                        <div className="title" id="title" onClick={() => onQuestionClick(question.qid)}>
                            <h3>{question.title}</h3>
                        </div>
                        <div className="metadata" id="metaData">
                            <span className="username">{question.askedBy}</span> asked <span className="date"> {questionTime(question)} </span>
                        </div>    
                    </div>
                    <div className='tags'> {model.getAllTags(question).map((tag, index) => 
                    (<span className='eachTag' key={index}>{tag}</span>
                    ))}
                    </div>
                </div>
            )): <div></div>}<div className = "b"></div>
        </div>
    )
}

export default Questions;

